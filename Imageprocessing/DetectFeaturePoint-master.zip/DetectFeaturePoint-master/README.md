# DetectFeaturePoint
Opencv下利用SIFT、SURF、ORB三种特征点实现图像匹配

1.release下的exe可以直接运行

2.opencv程序如果不能运行，可以直接把你的exe程序和安装的opencv路径下的相关的dll和exe放在一起就行了

3.更高效的算法需要改进，这个只是实现了最最简单的demo

![20170113140932376](C:\Users\2010yhh\Desktop\20170113140932376.jpg)